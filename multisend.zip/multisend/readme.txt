=== Plugin Name ===
Contributors: PayCall
Donate link: https://www.paycall.co.il/
Tags: PayCall
Requires at least: 4.5
Tested up to: 5.7.1
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
PayCall Multisend SMS & TTS Support 66 languages

== Description ==
 
PayCall Multisend SMS & TTS Support 66 languages

Support for sending to Kosher numbers

For contact us: [PayCall](https://www.paycall.co.il/en/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)

Paycall is a leading company in the online payments and management systems fields for measuring advertising, leads and calls. The advanced systems that we have developed are based on much professional experience and know-how, and an understanding of the market and changes taking place in it, which enable us to provide solutions for a broad range of customers commencing from websites, television channels, radio stations, and the press through small and large business proprietors. At Paycall, you will receive systems that are adapted to your needs, advanced and stable systems and personal, quality and reliable service.

Multisend SMS & TTS plugin provide integration with 3rd party plugins and core Wordpress functionality 

        WooCommerce , Contact Form 7 , Elementor Forms , POJO FORMS

 
== Installation ==
 
1. Upload the plugin folder to the /wp-content/plugins/ directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the ‘Plugins’ screen in WordPress
 
== Changelog ==
 
= 1.0 = Release
